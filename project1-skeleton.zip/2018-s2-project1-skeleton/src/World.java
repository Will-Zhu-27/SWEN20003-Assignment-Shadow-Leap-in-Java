import org.newdawn.slick.Graphics;
import org.newdawn.slick.Input;

public class World {
	public World() {
		// Perform initialisation logic
	}
	
	public void update(Input input, int delta) {
		// Update all of the sprites in the game
	}
	
	public void render(Graphics g) {
		// Draw all of the sprites in the game
	}
}
